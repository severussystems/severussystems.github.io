(function() {

    const severus_dl_a_tag_id = "severus-open-positions-link";

    let check_severus_dl_a_tag = function(){
        let severus_dl_a_tag = document.querySelector('a#'+severus_dl_a_tag_id);
        console.log("Severus a tag: "+severus_dl_a_tag);
        console.log(severus_dl_a_tag);
        if (severus_dl_a_tag) {
            console.log("Found Severus a tag already added");
            return true;
        }
        return false;
    };

    if (check_severus_dl_a_tag()) {
        return;
    }

	let user_name = document.querySelector('button#dropdownMenuProfile').innerText.trim();
	console.log(user_name);
	let date_YYYYMMDD = new Date().toISOString().slice(0,10);
	console.log(date_YYYYMMDD);

    let download_func = function(e) {
        let broker_drop_down = document.querySelector('#strategyFilter4');
		let broker_name = "";
		if (broker_drop_down) {
            broker_name = broker_drop_down[broker_drop_down.selectedIndex].innerText.trim();
		} else {
            broker_name = document.querySelector('label[for="modalFilterSelect8"]').parentElement.innerText.trim();
        }
        console.log(broker_name);

        let values = Array();
        document.querySelectorAll('div.rdt_Table div.rdt_TableBody div.rdt_TableRow div.rdt_TableCell').forEach(function(cell_element){
            let cell_value = cell_element.innerText.trim();
            // console.log("Cell value:"+cell_value);
            values.push(cell_value);
        });
        console.log("Values length:"+values.length);
        if(values.length == 0) {
            return false;
        }
        let txtString = values.join("\n");
		let file = new Blob([txtString], {type: "text/plain"});
		if (window.navigator.msSaveOrOpenBlob) { // IE10+
			window.navigator.msSaveOrOpenBlob(file, filename);
			return false;
		}
        let url = URL.createObjectURL(file);
        let a = e.currentTarget;
        a.href = url;
        a.download = "tt-dash-"+broker_name+"-open-positions-"+user_name+"-"+date_YYYYMMDD+".txt";
        return true;
    };


    let dash_tab_links = [...document.querySelectorAll('ul.dashboard-tabs li a')].filter(e => e.innerText == "Open Positions");
    if (dash_tab_links.length == 0) {
        return;
    }

    let check_and_add_severus_dl_a_tag = function(ev) {
        console.log("Open position tab clicked");
        if(check_severus_dl_a_tag()) {
            return true;
        }
        let title_blocks = document.querySelectorAll('p.dashboard__block-title');
        console.log(title_blocks);
        let open_position_dashboard_block = [...title_blocks].filter(e => e.innerText.trim() === "Open Position")[0];
        if(!open_position_dashboard_block) {
            console.log("open_position_dashboard_block not found | "+open_position_dashboard_block);
            return true;
        }
        let dashboard_block_title = open_position_dashboard_block.innerText.trim();
        console.log(dashboard_block_title);
        if (dashboard_block_title == "Open Position") {
            console.log("Found Open Position title");
        } else {
            console.log("Open Position tab not focussed");
            return true;
        }

        let a = document.createElement("a");
        a.id = severus_dl_a_tag_id;
        a.href = "#";
        a.download = "open-positions.txt";
        a.innerText = "Export as TXT";
        a.onclick = download_func;
        a.classList.add("icon-font");
        a.classList.add("icon-cvs");

        let dash_block_header = open_position_dashboard_block.parentElement;
        let dash_block_head_dropdown = dash_block_header.querySelector('div.dashboard__block-header--option');
        dash_block_head_dropdown.insertAdjacentElement('beforebegin', a);

        return true;
    }

    let open_pos_dash_tab_link = dash_tab_links[0];
    open_pos_dash_tab_link.addEventListener('click', function(ev) {
        setTimeout(function() {
            check_and_add_severus_dl_a_tag(ev);
        }, 1000);
        return true;
    });

})();
