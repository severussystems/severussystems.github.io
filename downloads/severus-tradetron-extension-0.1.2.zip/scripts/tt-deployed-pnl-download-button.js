(function() {
    let severus_dl_a_tag = document.querySelector('a#severus-deployed-pnl-link');
    console.log("Severus a tag: "+severus_dl_a_tag);
    console.log(severus_dl_a_tag);
    if (severus_dl_a_tag) {
        console.log("Found Severus a tag already added");
        return;
    }

	let user_name = document.querySelector('button#dropdownMenuProfile').innerText.trim(); // .text().trim();
	console.log(user_name);
	let date_YYYYMMDD = new Date().toISOString().slice(0,10);
	console.log(date_YYYYMMDD);

    let a = document.createElement("a");
    a.id = "severus-deployed-pnl-link";
	a.href = "#";
	let filename = "deployed-pnl-"+user_name+"-"+date_YYYYMMDD+".csv";
	a.download = filename;
	a.text = "Export PnL";

	// class="mr-1 mb-1 px-3 py-1 bg-white "
	a.classList.add("mr-1");
	a.classList.add("mb-1");
	a.classList.add("px-3");
	a.classList.add("py-1");
	a.classList.add("bg-white");

    a.onclick = function() {
        let res = new Array();
        document.querySelectorAll('div.strategy__section').forEach(function(strategy_section_element){
            let dep_id = strategy_section_element.id;
            console.log("Strategy section:"+strategy_section_element+"|"+dep_id);
            if (dep_id) {
                strategy_section_element.querySelectorAll('option[value="All"]').forEach(function(all_pnl_element){
                    let all_val_text = all_pnl_element.innerText.trim();  // "All (₹  -3,325)"
                    console.log(""+dep_id+":"+all_val_text);
                    all_val_text = all_val_text.substring(8);
                    all_val_text = all_val_text.substring(0, all_val_text.length - 1).replace(',', '');
                    console.log(all_val_text);

                    res.push([dep_id, parseFloat(all_val_text)]);
                });
            }
        });

        if (res.length == 0) {
            console.log('No pnl data to export');
            return false;
        }
        let csvDataString = res.map(e => e.join(",")).join("\n")
        // console.log(csvDataString);

        let csvHeaderString = "DeploymentId,PnL";
        let csvString = csvHeaderString + "\n" + csvDataString;

		let file = new Blob([csvString], {type: "text/csv"});
		if (window.navigator.msSaveOrOpenBlob) {// IE10+
			window.navigator.msSaveOrOpenBlob(file, filename);
			return false;
		}
		// Others
        let url = URL.createObjectURL(file);
        a.href = url;
        return true;
    }

    let parent_element = document.querySelector('p.deployed__summary-title');
    console.log("Parent element: "+parent_element);
    span_el = document.createElement("span");
    span_el.id = 'severus-deployed-pnl-link-span';
    span_el.classList.add("s-profile__description-profile-tags");
    span_el.classList.add("ml-2");
    span_el.appendChild(a);
    parent_element.appendChild(span_el);

})();
